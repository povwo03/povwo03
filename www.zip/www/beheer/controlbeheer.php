<?php 
          if(empty($_SESSION["ww"]) or empty($_SESSION["gnaam"]));
          
          else 
            {$gnaam =$_SESSION["gnaam"];  $ww = $_SESSION["ww"];
             $query ="SELECT username, password, nummer, functie FROM users
                       WHERE username = '$gnaam' AND password='$ww'";
             $respons=mysql_query($query) or die('fout in query controlbeheer');
	           $count=mysql_num_rows($respons);
	           $row=mysql_fetch_row($respons);
	           $functie=$row[3];
            
             if( $count<>1 or $functie<> "admin")
                { header('location: foutbeheer.php');}
            
             else { $behnr = $row[2];}
            }        
        ?>

