<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="nl" lang="nl">
    <head>
      <title> foutafhandeling  </title> 
       <link rel="stylesheet" type="text/css" href="../style.css"> 
       <?php  
          include("../include/connection.php");  
          include("controlbeheer.php")
          
       ?>
    </head>

    <body>
      <div id ="logo">  <img class=logo src="../images/hlwlogo.jpg" > </div>    

      <div id ="header"> Hotel de Buijtelaar  </div>   
     
      <div id="menu">
         <ul> <li> <a href="index.html">home</a></li>
              <li> <a href="../php/kamers.php">Kamers</a>  </li>
              <li> <a href="../php/aanbieding.php">Aanbiedingen </a>  </li>
              <li> <a href="http://www.google.nl/">afsluiten</a>  </li>
         </ul>
      </div>  
      
      <div id= "inhoud">
       <div id ="loggen">
           <a href="../loggen/inlogform.html"> inloggen </a> 
       </div>
       <h2>  Verkeerd ingelogd  </h2>
       Je bent niet inloged of verkeerd als beheerder ingelogd. <br>
       Daarom heb je geen toegang tot de beheerderpagina's.           
      
      </div> 
    </body>
</html>
