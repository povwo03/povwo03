<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="nl" lang="nl">
  <head>
     <title>Beheer</title>
     <link rel="stylesheet" type="text/css" href="../style.css"> 
     <?php  
          include("../include/connection.php");  
          include("controlbeheer.php")
     ?>
  </head>

  <body>
   <div id ="logo">  <img class=logo src="../images/hlwlogo.jpg" > </div>    

      <div id ="header"> Hotel de Buijtelaar  </div>   
     
   <div id="menu">
     <ul>  <li> <a href="indexbeheer.php">homebeheer</a>  </li>
           <li> <a href="kamersb.php">Kamers</a>  </li>
           <li> <a href="aanbiedingb.php">Aanbiedingen</a>  </li> 

     </ul>
   </div>    
   
   <div id= "inhoud">
       <div id ="loggen">
           <a href="../loggen/uitloggen.php"> uitloggen </a> 
       </div>
       <br> 
       Je bent nu in een gedeelte van de site wat voor <br>
       de beheerder toegankelijk is. <br>
       <br>
       Onder de knop "Kamers" kun je de gegevens van de Kamers wijzigen. <br>
       Onder de knop "Aanbiedingen" kun je een Aanbieding toevoegen. <br>
       <br>
       Je ziet dat de link "inloggen" gewijzigd is in "uitloggen". <br>
       Gebruik altijd de knop "uitloggen" voor het verlaten van het beheer-deel.
       
   </div>     
  </body>
</html>
