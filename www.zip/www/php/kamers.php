<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="nl" lang="nl">
    <head>
      <title> Prijslijst  </title> 
       <link rel="stylesheet" type="text/css" href="../style.css"> 
       <?php   include("../include/connection.php");   ?>
    </head>
    
    <body>
      <div id ="logo">  <img class=logo src="../images/hlwlogo.jpg"> </div>    

      <div id ="header"> Hotel de Buijtelaar  </div>   
     
      <div id="menu">
         <ul> <li> <a href="../index.html">home</a>  </li>
              <li> <a href="kamers.php">Kamers</a>  </li>
              <li> <a href="aanbieding.php">Aanbiedingen </a>  </li>
              <li> <a href="../index.html">afsluiten</a>  </li>
         </ul>
      </div>  
      
      <div id= "inhoud">
         <h2> Prijslijst kamers</h2>

         <table border="1">
         <tr> <th>naam</th> <th>Prijs &#8364;</th>  </tr>
         <?php
            //gegevens opvragen uit database
            $query = "SELECT kamernaam, kamerprijs
            FROM kamers
            ORDER BY kamernaam";
            $respons=mysql_query($query);

            //opgehaalde gegevens printen
            while($row=mysql_fetch_row($respons))
            { print(" <tr>
                          <td>$row[0]</td>
                          <td>$row[1]</td>
                      </tr>
                    ");
            }
        ?>
         </table>
      </div>
  </body>
</html>
