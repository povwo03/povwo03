<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="nl" lang="nl">
  <head>
     <title>Kamer verwijderen</title>
       <link rel="stylesheet" type="text/css" href="../style.css"> 
     <?php include("../include/connection.php"); ?>
  </head>
	<body>
	<div id ="logo">  <img class=logo src="../images/hlwlogo.jpg"> </div>    

      <div id ="header"> Hotel de Buijtelaar  </div>   
     
      <div id="menu">
         <ul> <li> <a href="../index.html">home</a>  </li>
              <li> <a href="../php/wijzigkamer.php">Wijzigen</a>  </li> 
              <li> <a href="../php/voegkamertoe.php">Toevoegen</a>  </li>
              <li> <a href="../php/verwijderkamer.php">Verwijderen</a>  </li>
         </ul>
      </div>
      <div id= "inhoud">
		<h3> Kamer verwijderen </h3>
		<?php
	// ----- keuzelijst van alle gegevens --------
if(empty($_POST))
{
	
// maak query om alle kamer op te vragen
$query= "SELECT * FROM kamers";
$respons =mysql_query($query) or die;

// zet opgevraagde gegevens in keuzelijst
print(" <form method='post' action='verwijderkamer.php' >
<select name= 'kamercode'>
");
While($row=mysql_fetch_row($respons))
{ print(" <option value=$row[0]>
$row[0] $row[1] $row[2] .... $row[6]
</option>
");
}
print(" </select>
<input type='submit' value='verwijderen'>
</form>
");
}				
	//	-------- gegevens verwijderen uit database --------	
	if( ! empty($_POST))
	{  $ID = $_POST['kamercode'];
	// --------- maak verwijder query ----------------------
	$query = "DELETE FROM kamers WHERE kamercode = $ID";
	if(!mysql_query($query))	{ print("verwijderen is mislukt"); }
	else
	{print(" Gegevens zijn verwijderd uit database <br />
	Nog meer verwijderen? <br />
	<a href=verwijderkamer.php>Ja</a>
	");
	}
	}
	?>
	</body>
	</html>
