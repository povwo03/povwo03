<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="nl" lang="nl">
    <head>
      <title> Aanbieding wijzigen  </title> 
       <link rel="stylesheet" type="text/css" href="../style.css"> 
       <?php   include("../include/connection.php");   ?>
    </head>
<body>
<div id ="logo">  <img class=logo src="../images/hlwlogo.jpg" > </div>    

      <div id ="header"> Hotel de Buijtelaar  </div>   
     
      <div id="menu">
         <ul> <li> <a href="../index.html">home</a>  </li>
              <li> <a href="../php/wijzigaanbieding.php">Wijzigen</a>  </li> 
              <li> <a href="../php/voegaanbiedingtoe.php">Toevoegen</a>  </li>
              <li> <a href="../php/verwijderaanbieding.php">Verwijderen</a>  </li>
         </ul>
      </div>  
      
      <div id= "inhoud">
		<?php
		
	// ----- kies een aanbieding uit keuzelijst van alle aanbiedingen --------
if(empty($_POST))
{
	
// maak query om alle gegevens op te vragen
$query= "SELECT * FROM aanbiedingen";
$respons =mysql_query($query) or die;

// zet opgevraagde gegevens in keuzelijst
print(" <form method='post' action='verwijderaanbieding.php' >
<select name= 'aanbiedingcode'>
");
While($row=mysql_fetch_row($respons))
{ print(" <option value=$row[0]>
$row[0]. $row[1] $row[2] .... $row[6]
</option>
");
}
print(" </select>
<input type='submit' value='verwijderen'>
</form>
");
}				
	//	-------- gegevens uit database verwijderen --------	
	if( ! empty($_POST))
	{  $ID = $_POST['aanbiedingcode'];
	// --------- maak verwijder query ----------------------
	$query = "DELETE FROM aanbiedingen WHERE aanbiedingcode = $ID";
	if(!mysql_query($query))	{ print("verwijderen is mislukt"); }
	else
	{print(" Gegevens zijn verwijderd uit database <br />
	Nog meer verwijderen? <br />
	<a href=verwijderaanbieding.php>Ja</a>
	");
	}
	}
	?>
	</body>
	</html>
