<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="nl" lang="nl">
  <head>
     <title>Kamer wijzigen</title>
       <link rel="stylesheet" type="text/css" href="../style.css"> 
     <?php include("../include/connection.php"); ?>
  </head>
<body>
<div id ="logo">  <img class=logo src="../images/hlwlogo.jpg" > </div>    

      <div id ="header"> Hotel de Buijtelaar  </div>   
     
      <div id="menu">
         <ul> <li> <a href="../index.html">home</a>  </li>
              <li> <a href="../php/wijzigkamer.php">Wijzigen</a>  </li> 
              <li> <a href="../php/voegkamertoe.php">Toevoegen</a>  </li>
              <li> <a href="../php/verwijderkamer.php">Verwijderen</a>  </li>
         </ul>
      </div>  
      <div id= "inhoud">

<?php

// ------ maak keuzelijst van alle gegevens ----------------------
if (empty($_POST))
{ print("<h3> Wijzig kamer </h3>");

// ------ maak query om alle gegevens op te vragen --------
$query="SELECT * FROM kamers";
$respons=mysql_query($query) or die;

// ------ zet opgevraagde gegevens in keuzelijst ------------
print(" <form method='post' action='wijzigkamer.php'>
<select name= 'kamercode'>
");
While($row=mysql_fetch_row($respons))
{ print(" <option value=$row[0]>
$row[0] $row[1] $row[2]
</option>
");
}
print(" </select>
<input type='submit' value='gegevens'>
</form>
");
}

// ----------- gegevens wijzigen -----------------
if (! empty($_POST['kamercode']))
{ $ID = $_POST['kamercode'];
print("<h2> Wijzig de gegevens </h2>");

// ---- maak query voor alle gegevens ------------
$query="SELECT * FROM kamers WHERE kamercode = $ID";
$respons=mysql_query($query) or die;
$row=mysql_fetch_row($respons);

// ---- maak wijzigingsformulier ------------------------------------
print("<form method='post' action='wijzigkamer.php' > ");
print(" <input type='hidden' name='kamercode' value='$row[0]'>
kamernaam: <input type='text' name='kamernaam' value='$row[1]'> <br />
kamerprijs: <input type='text' name='kamerprijs' value='$row[2]'> <br />
");
print("<br /> <input type='submit' value='opslaan'>");
print("</form>");
}

// ------------ wijzigingen opslaan ------------------------------------------
if (! empty($_POST['kamercode']))
{ $ID = $_POST['kamercode'];
$kamernaam = $_POST['kamernaam']; 
$kamerprijs = $_POST['kamerprijs'];

// ------------- wijzigings query maken -----------------------------------------
$query ="UPDATE kamers SET kamernaam='$kamernaam', kamerprijs='$kamerprijs'
WHERE kamercode=$ID";

// ------------- controle op juiste verwerking -----------------------------------
if(!mysql_query($query)) { print("wijzig de gegevens"); }
else { print (" Gegevens zijn gewijzigd in database <br />
Nog meer wijzigingen? <br />
<a href=wijzigkamer.php>Ja</a> ");
	}
}

?>
</body>
</hmtl>