<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="nl" lang="nl">
  <head>
     <title>Kamer wijzigen</title>
       <link rel="stylesheet" type="text/css" href="../style.css"> 
     <?php include("../include/connection.php"); ?>
  </head>
</body>
<div id ="logo">  <img class=logo src="../images/hlwlogo.jpg"> </div>    

      <div id ="header"> Hotel de Buijtelaar  </div>   
     
      <div id="menu">
         <ul> <li> <a href="../index.html">home</a>  </li>
              <li> <a href="../php/wijzigkamer.php">Wijzigen</a>  </li> 
              <li> <a href="../php/voegkamertoe.php">Toevoegen</a>  </li>
              <li> <a href="../php/verwijderkamer.php">Verwijderen</a>  </li>
         </ul>
      </div>
      <div id= "inhoud">


<?php

// ----- invulformulier als POST is leeg ---------
if( empty($_POST ))
{ print("
<h3> Kamer toevoegen </h3>
<form method='post' action='voegkamertoe.php'>
kamer naam: <input type='text' name='kamernaam'><br>
kamer prijs: <input type='text' name='kamerprijs'><br>
<input type='submit' value='verzenden' > <br>
<input type='reset' value='wissen'> <br> <br>
</form>
");
}

// ---- gegevens aan tabel toevoegen als basisgegevens ingevuld zijn --------
if ( !empty($_POST ))
{

$kamernaam = $_POST['kamernaam']; 
$kamerprijs = $_POST['kamerprijs'];

// ----------toevoeg-query maken ----------------------
$query ="INSERT kamers(kamercode,kamernaam,kamerprijs)
VALUES(kamercode,'$kamernaam','$kamerprijs')";
if( !mysql_query($query)) { print("invoer gegevens is mislukt"); }
else { print(" Gegevens zijn ingevoerd in database <br>
Nog meer kamers toevoegen? <br>
<a href=voegkamertoe.php>Ja</a>
");
	}
}
?>
</body>
</htm