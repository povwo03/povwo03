<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="nl" lang="nl">
    <head>
      <title> Aanbieding wijzigen  </title> 
       <link rel="stylesheet" type="text/css" href="../style.css"> 
       <?php   include("../include/connection.php");   ?>
    </head>
<body>
<div id ="logo">  <img class=logo src="../images/hlwlogo.jpg" > </div>    

      <div id ="header"> Hotel de Buijtelaar  </div>   
     
      <div id="menu">
         <ul> <li> <a href="../index.html">home</a>  </li>
              <li> <a href="../php/wijzigaanbieding.php">Wijzigen</a>  </li> 
              <li> <a href="../php/voegaanbiedingtoe.php">Toevoegen</a>  </li>
              <li> <a href="../php/verwijderaanbieding.php">Verwijderen</a>  </li>
         </ul>
      </div>  
      
      <div id= "inhoud">

<?php

// ------ maak keuzelijst van alle gegevens ---------------
if (empty($_POST))
{ print("<h3> Kies een aanbieding </h3>");

// ------ maak query om alle gegevens op te vragen --------
$query="SELECT * FROM aanbiedingen";
$respons=mysql_query($query) or die;

// ------ zet opgevraagde gegevens in keuzelijst ------------
print(" <form method='post' action='wijzigaanbieding.php'>
<select name= 'aanbiedingcode'>
");
While($row=mysql_fetch_row($respons))
{ print(" <option value=$row[0]>
$row[0] $row[1] $row[2]
</option>
");
}
print(" </select>
<input type='submit' value='gegevens'>
</form>
");
}

// ----------- gegevens van een drankje wijzigen -----------
if (! empty($_POST['aanbiedingcode']))
{ $ID = $_POST['aanbiedingcode'];
print("<h2> Wijzig de gegevens </h2>");

// ---- maak query voor alle gegevens ---------------------
$query="SELECT * FROM aanbiedingen WHERE aanbiedingcode = $ID";
$respons=mysql_query($query) or die;
$row=mysql_fetch_row($respons);

// ---- maak wijzigingsformulier ------------------------------------
print("<form method='post' action='wijzigaanbieding.php' > ");
print(" <input type='hidden' name='aanbiedingcode' value='$row[0]'>
aanbiedingnaam: <input type='text' name='aanbiedingnaam' value='$row[1]'> <br />
aanbiedingprijs: <input type='text' name='aanbiedingprijs' value='$row[2]'> <br />
");
print("<br /> <input type='submit' value='opslaan' onClick='clearform();'>");
print("</form>");
}

// ------------ wijzigingen opslaan ------------------------------------------
if (! empty($_POST['aanbiedingcode']))
{ $ID = $_POST['aanbiedingcode'];
$aanbiedingnaam = $_POST['aanbiedingnaam']; 
$aanbiedingprijs = $_POST['aanbiedingprijs'];

// ------------- wijzigings query maken -----------------------------------------
$query ="UPDATE aanbiedingen SET aanbiedingnaam='$aanbiedingnaam', aanbiedingprijs='$aanbiedingprijs'
WHERE aanbiedingcode=$ID";

// ------------- controle op juiste verwerking -----------------------------------
if(!mysql_query($query)) { print("wijzig de gegevens"); }
else { print (" Gegevens zijn gewijzigd in database <br />
Nog meer wijzigingen? <br />
<a href=wijzigaanbieding.php>Ja</a> ");
}
}

?>
       
      </div>
</body>
</html>