<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="nl" lang="nl">
  <head>
     <title>Aanbieding toevoegen</title>
       <link rel="stylesheet" type="text/css" href="../style.css"> 
     <?php include("../include/connection.php"); ?>
  </head>
</body>
<div id ="logo">  <img class=logo src="../images/hlwlogo.jpg"> </div>    

      <div id ="header"> Hotel de Buijtelaar  </div>   
     
      <div id="menu">
         <ul> <li> <a href="../index.html">home</a>  </li>
              <li> <a href="../php/wijzigaanbieding.php">Wijzigen</a>  </li> 
              <li> <a href="../php/voegaanbiedingtoe.php">Toevoegen</a>  </li>
              <li> <a href="../php/verwijderaanbieding.php">Verwijderen</a>  </li>
         </ul>
      </div>
      <div id= "inhoud">
<?php
// ------------------------------------------------------------
// ----- invulformulier als POST is leeg ---------
if( empty($_POST ))
{ print("
<h3> aanbieding toevoegen </h3>
<form method='post' action='voegaanbiedingtoe.php'>
aanbieding naam: <input type='text' name='aanbiedingnaam'><br>
aanbieding prijs: <input type='text' name='aanbiedingprijs'><br>
<input type='submit' value='verzenden' > <br>
<input type='reset' value='wissen'> <br> <br>
</form>
");
}

// ---- gegevens aan tabel toevoegen als basisgegevens ingevuld zijn --------
if ( !empty($_POST ))
{

$aanbiedingnaam = $_POST['aanbiedingnaam']; 
$aanbiedingprijs = $_POST['aanbiedingprijs'];

// ----------toevoeg-query maken ----------------------
$query ="INSERT aanbiedingen(aanbiedingcode,aanbiedingnaam,aanbiedingprijs)
VALUES(aanbiedingcode,'$aanbiedingnaam','$aanbiedingprijs')";
if( !mysql_query($query)) { print("invoer gegevens is mislukt"); }
else { print(" Gegevens zijn ingevoerd in database <br>
Nog meer aanbiedings toevoegen? <br>
<a href=voegaanbiedingtoe.php>Ja</a>
");
	}
}
?>
</body>
</htm