-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: db
-- Gegenereerd op: 07 nov 2020 om 21:52
-- Serverversie: 5.7.24
-- PHP-versie: 7.2.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `poinf`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `aanbiedingen`
--

CREATE TABLE `aanbiedingen` (
  `aanbiedingcode` int(7) NOT NULL,
  `aanbiedingnaam` varchar(20) NOT NULL,
  `aanbiedingprijs` decimal(6,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Gegevens worden geëxporteerd voor tabel `aanbiedingen`
--

INSERT INTO `aanbiedingen` (`aanbiedingcode`, `aanbiedingnaam`, `aanbiedingprijs`) VALUES
(3245, 'zomertaanbieding', '89.00');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `beheer`
--

CREATE TABLE `beheer` (
  `beheernr` int(2) NOT NULL,
  `naam` varchar(15) NOT NULL,
  `functie` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Gegevens worden geëxporteerd voor tabel `beheer`
--

INSERT INTO `beheer` (`beheernr`, `naam`, `functie`) VALUES
(1, 'cornelis', 'systeembeheerder'),
(2, 'janrap', 'applicatieprogrammeur');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `kamers`
--

CREATE TABLE `kamers` (
  `kamercode` int(6) NOT NULL,
  `kamernaam` varchar(50) NOT NULL,
  `kamerprijs` decimal(6,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Gegevens worden geëxporteerd voor tabel `kamers`
--

INSERT INTO `kamers` (`kamercode`, `kamernaam`, `kamerprijs`) VALUES
(31124, 'Royal Suite', '330.00'),
(201915, 'Wedding Suite', '750.00'),
(201916, 'lowbudget', '60.00');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `users`
--

CREATE TABLE `users` (
  `userid` int(6) NOT NULL,
  `username` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL,
  `code` varchar(3) NOT NULL,
  `nummer` int(11) NOT NULL,
  `functie` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Gegevens worden geëxporteerd voor tabel `users`
--

INSERT INTO `users` (`userid`, `username`, `password`, `code`, `nummer`, `functie`) VALUES
(1, 'admin', 'admin', '-', 0, 'admin'),
(11, 'poinf', 'poinf', '-', 1, 'admin');

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `aanbiedingen`
--
ALTER TABLE `aanbiedingen`
  ADD PRIMARY KEY (`aanbiedingcode`);

--
-- Indexen voor tabel `beheer`
--
ALTER TABLE `beheer`
  ADD PRIMARY KEY (`beheernr`);

--
-- Indexen voor tabel `kamers`
--
ALTER TABLE `kamers`
  ADD PRIMARY KEY (`kamercode`);

--
-- Indexen voor tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `aanbiedingen`
--
ALTER TABLE `aanbiedingen`
  MODIFY `aanbiedingcode` int(7) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3247;

--
-- AUTO_INCREMENT voor een tabel `kamers`
--
ALTER TABLE `kamers`
  MODIFY `kamercode` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=201917;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
