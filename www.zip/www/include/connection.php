<?php 
       $server = "mysql.dorian.hlw.nl:13306";
       $user = "povwo03";
       $wachtwoord = "povwo03";
       $database = "povwo03";
       $query = "";
       $resultaat ="";
       $db = mysql_connect($server,$user,$wachtwoord) or die('verbinding met server mislukt:'.mysql_error());
       mysql_select_db($database,$db) or die('databse foutverbinding:'.mysql_error());
?>
 