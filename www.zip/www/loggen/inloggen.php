<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="nl" lang="nl">
  <head>
     <title>inloggen</title>
     <link rel="stylesheet" type="text/css" href="../style.css">
     <?php
        include("../include/connection.php"); 
     ?>
  </head>
  
  <body>
   <div id ="logo">  <img class=logo src="../images/hlwlogo.jpg" > </div>    

      <div id ="header"> Hotel de Buijtelaar  </div>   
     
   <div id="menu">
      <ul> <li> <a href="../index.html">home</a>  </li>
           <li> <a href="../php/kamers.php">Kamers</a>  </li>
           <li> <a href="../php/aanbieding.php">Aanbieding</a>  </li>
           <li> <a href="http://www.google.nl/">afsluiten</a>  </li>
      </ul>
   </div>    
   
   <div id= "inhoud"> 
     <?php
      if(!empty($_POST["naam"]) and !empty($_POST["wachtwoord"])) 
         { $gnaam =$_POST["naam"];  $ww = $_POST["wachtwoord"];
           $query ="SELECT * FROM users WHERE username = '$gnaam' AND password='$ww'";
           $respons=mysql_query($query) or die('fout in query personeel');
	         $count=mysql_num_rows($respons);
	         $row=mysql_fetch_row($respons);
	         $functie=$row[5];
                    
 	         if($count<>1)
 	           { print("Je inloggegevens zijn niet correct ingevuld! <br /> 
 	                  Ga opnieuw inloggen:<br />
 	                  <div id ='loggen'>
                       <form action='inloggen.php' method='post'>
                           Gebruikersnaam: <input type='text' name='naam' /><br />
                           Wachtwoord: <input type='password' name='wachtwoord' /><br />
                           <input type='submit' value='Inloggen' >
                       </form>
                    </div>");
              }      
          
           else
              { $_SESSION["gnaam"] = $_POST["naam"];
                $_SESSION["ww"] = $_POST["wachtwoord"];              
                if($functie == "admin")
                  { header('location: ../beheer/indexbeheer.php');         }   
               }
         }
       if(empty($_POST["naam"]) or empty($_POST["wachtwoord"])) 
         { print("Je hebt je gebruikersnaam en/of je wachtwoord niet ingevuld  <br />
                Ga volledig inloggen:<br />
                <div id ='loggen'>
                   <form action='inloggen.php' method='post'>
                       Gebruikersnaam: <input type='text' name='naam' /><br />
                       Wachtwoord: <input type='password' name='wachtwoord' /><br />
                       <input type='submit' value='Inloggen' >
                    </form>
                </div> ");
         } 
     ?>
   </div>     
 </body>
</html>
